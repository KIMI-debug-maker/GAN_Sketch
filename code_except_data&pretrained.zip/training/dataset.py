from jittor import transform
from jittor import dataset

def create_dataloader(data_dir, size, batch,img_channel=3):
    mean, std = [0.5 for _ in range(img_channel)], [0.5 for _ in range(img_channel)]

    transformer = transform.Compose([
        transform.Resize(size),
        transform.ImageNormalize(mean=[0.5], std=[0.5]),
    ])

    loader = dataset.ImageFolder(data_dir,transform=transformer).set_attrs(batch_size=batch, shuffle=True, drop_last=True)
    
    show=False
    if show:
        for i,(a,b) in enumerate(loader):
            print(a.shape)
            break
    #a->pic,channel_first,b->label   
    return loader

#create_dataloader('../data/image',256,16)