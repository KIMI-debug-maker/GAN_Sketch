wget https://www.cs.cmu.edu/~gansketching/files/weights.zip -O ./weights/weights.zip
unzip ./weights/weights.zip -d ./weights
rm ./weights/weights.zip
